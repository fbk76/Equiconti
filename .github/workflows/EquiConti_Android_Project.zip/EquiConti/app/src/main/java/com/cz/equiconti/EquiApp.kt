package com.cz.equiconti

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EquiApp : Application()
